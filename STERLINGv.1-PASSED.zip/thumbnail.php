	<ul id="da-thumbs" class="da-thumbs span12" >
					<li>
						<a href="">
							<img src="images/b.jpg" />
							<div><span>WEDDINGS</span></div>
						</a>
					</li>
					<li>
						<a href="">
							<img src="images/c.jpg" />
							<div><span>BIRTHDAYS</span></div>
						</a>
					</li>
					<li>
						<a href="">
							<img src="images/d.jpg" />
							<div><span>CORPORATE EVENTS</span></div>
						</a>
					</li>
					<li>
						<a href="">
							<img src="images/e.jpg" />
							<div><span>OTHER GATHERINGS</span></div>
						</a>
					</li>
					
				
				
				</ul>
						
                       