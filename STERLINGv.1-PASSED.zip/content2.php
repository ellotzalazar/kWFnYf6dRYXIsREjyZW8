
	<div>
	<iframe width="350" height="300" frameborder="10" scrolling="no" marginheight="auto" marginwidth="auto"
           src="https://www.google.com/maps/d/embed?mid=1t7uwezdJO9rd68l_NuMJaKtDZ2w">
    </iframe>
	</div>