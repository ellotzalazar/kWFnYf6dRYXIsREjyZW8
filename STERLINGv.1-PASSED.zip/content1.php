	<div class="text_content">
					<p>
	STERLING DIGITAL PHOTOGRAPHY offers high quality of photo and video coverage for Weddings, Baptismals, Kiddie events and other Small Gatherings around cavite area. <p> Also offered  are video editing, video transfer from VHS to DVD and Layout work</p>

	<div> <p>Our team of photographers and videographers each have extensive wedding coverage training and experience. We regularly cover all sizes and types of wedding throughout the the cavite are</p></div>

					</p>
					</div>