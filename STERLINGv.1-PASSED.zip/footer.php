   <div style="position: bottom;">   
   <footer class="footer">
      
        <p>Copyright � 2017 Sterling Digital. All Rights reserved</p>

    </footer>
</div>
</body>
</html>