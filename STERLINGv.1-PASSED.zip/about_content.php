
<div class="alert alert-info span12"><strong>About US</strong></div>
<div class="about span12">
<p>Our company's primary business line Is Photo Developing and Printing. We enable clients to lower our rates, since we print our own photos. Our company is one of the few photo studios today that has its own digital photo laboratories.
Personalized photos and video services are what make NicePrint Photo Co. stand out among other players in our Industry</p>

<p>Our staff is equipped with multiple professional DSLR cameras and professional lighting equipment to ensure your event is captured exactly as you envision it, while at the same time, ensuring your photos and footage is backed up and safe.</p>
<p>
Typically booked along with your wedding, we provide fun and creative engagement photo sessions. This is an excellent way to get to know your wedding photographer. 
</p>
</div>
