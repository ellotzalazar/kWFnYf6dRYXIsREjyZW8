<?php
include('dbcon.php');
$get_id = $_GET['id'];

	
	
	mysql_query("update package set service_offer='$service where service_offer==$service'")or die(mysql_error()); 

?>
