<?php 
mysql_select_db('cedd',mysql_connect('localhost','root',''))or die(mysql_error());
?>