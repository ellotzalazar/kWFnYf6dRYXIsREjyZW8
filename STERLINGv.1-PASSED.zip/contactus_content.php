<div>
<p>
</p>
<p style="text-align: center;">

<b>For more comments and suggestions. please feel free to message us on the contacts listed below.</b>
<br><br>
Tel. No. (046) 484-8142 / Mobile# 09985584792
<br>
Email: sterlingdps@gmail.com 
<br>
http://www.facebook.com/SterlingDigitalphotography 
<br><br>
We hope to serve you the best photo and video experience in the future. Thank you!
<br><br><br>
<b>VISIT OUR OFFICE</b>
<br><br>
Office Hours
<br>
Monday - Friday (9:00 am to 6:00 pm)
<br>
Saturday (9:30 am to 1:00 pm)
<br>
Unit a DM Bldg.
<br>
Sterling Mile Beside Barangay Hall Barangay Salawag,
<br>
Salawag, Dasmarinas, Cavite, Philippines
</p>
</div>
